function multiply(a,b)
{
    var mul=a*b;
    return mul;
}

module.exports=multiply;