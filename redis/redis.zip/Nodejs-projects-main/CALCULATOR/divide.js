function divide(a,b)
{
    var div=a/b;
    return div;
}

module.exports=divide;