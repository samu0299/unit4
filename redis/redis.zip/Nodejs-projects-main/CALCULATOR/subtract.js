function subtract(a,b)
{
    var sub=a-b;
    return sub;
}

module.exports=subtract;