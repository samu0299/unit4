function add(a,b)
{
    var sum=a+b;
    return sum;
}

module.exports= add;
